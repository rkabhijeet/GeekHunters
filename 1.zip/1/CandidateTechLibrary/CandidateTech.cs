﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using DataLayerConnect;


// business layer
namespace CandidateTechLibrary
{
    public class CandidateTech
    {
        public DataTable selectAllCandTech()
        {
            DataTable dt = new DataTable();
            CandidateTechService ts = new DataLayerConnect.CandidateTechService();
            dt = ts.SelectCandidateTechnology();
            return dt;
        }
    }
}
