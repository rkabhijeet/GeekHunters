﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using DataLayerConnect;


// business layer
namespace CandidateTechLibrary
{
    public class Candidate
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }


        public Boolean addCandidate(Candidate cand, DataTable table)
        {
            string fname, lname;
            fname = cand.FirstName;
            lname = cand.LastName;
            Boolean success;
            CandidateService cs = new DataLayerConnect.CandidateService();
            success = cs.InsertCandidate(cand.FirstName, cand.LastName, table);

            return success;
        }

    }
}
