﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using DataLayerConnect;
using System.Linq;


// business layer
namespace CandidateTechLibrary
{
    public class Technology
    {
        public string TechnologyName { get; set; }

        public DataTable selectTechnologyNames()
        {
            DataTable dt = new DataTable();
            TechnologyService ts = new DataLayerConnect.TechnologyService();
            dt = ts.SelectTechnologies();
            return dt;
        }


        public Boolean addTechnology(Technology tech)
        {
            string techName;
            techName = tech.TechnologyName;
            
            Boolean success;
            TechnologyService ts = new DataLayerConnect.TechnologyService();
            success = ts.InsertTechnology(techName);

            return success;
        }


    }


}
