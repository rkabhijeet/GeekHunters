﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace DataLayerLibrary
{
    class DBConnection : IDBConnection
    {
        public void open()
        {
            System.Data.sqlclient.SqlConnection con = new SqlConnection("Integrated Security=SSPI;Initial Catalog=Test;Data Source=ABHIJIT-PC");

        }

        public void close()
        {

        }
    }
}
