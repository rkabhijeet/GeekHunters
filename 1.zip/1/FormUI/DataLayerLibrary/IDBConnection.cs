﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayerLibrary
{
    interface IDBConnection
    {
        void open();
        void close();
    }
}
