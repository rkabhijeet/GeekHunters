﻿using CandidateTechLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormUI
{
    public partial class FrmTechnology : Form
    {
        public FrmTechnology()
        {
            InitializeComponent();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (txtTech.Text == "")
            { MessageBox.Show("Technology Name can not be blank"); }
            txtTech.Focus();
        }

        private void btnTSubmit_Click(object sender, EventArgs e)
        {
            if ( txtTech.Text == "")
            {
                MessageBox.Show("Please enter Technology Name");
            }
            else
            {

                Technology tech = new Technology();
                Boolean isSuccess;
                tech.TechnologyName = txtTech.Text;
                

                
                isSuccess = tech.addTechnology(tech);
                if (isSuccess == true)
                {
                    MessageBox.Show("Technology Added Successfully");
                    txtTech.Text = "";
                    txtTech.Focus();

                }
                else { MessageBox.Show("Record not saved"); }

            }

        }
    }
}
