﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CandidateTechLibrary;

/// <summary>
/// form used to add candidate details
/// </summary>

namespace FormUI
{
    public partial class FrmCandidate : Form
    {
        public FrmCandidate()
        {
            InitializeComponent();
        }

        #region Form Events

        private void FrmCandidate_Load(object sender, EventArgs e)
        {
            // Fill up list view with technology names from database
            DataTable dt = new DataTable();
            Technology tech = new Technology();
            dt = tech.selectTechnologyNames();

            lvTechnology.View = View.Details;
            lvTechnology.Columns.Add("TechID",1);
            lvTechnology.Columns.Add("TechnologyName", 283);
            lvTechnology.Items.Clear();
            lvTechnology.FullRowSelect = true;

            foreach (DataRow row in dt.Rows)
            {
                ListViewItem item = new ListViewItem(row["TechID"].ToString());
                item.SubItems.Add(row["TechnologyName"].ToString());
                lvTechnology.Items.Add(item);
            }
            txtFirstName.MaxLength = 50;
            txtLastName.MaxLength = 50;
        }

        #endregion

        #region Control Events

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (lvTechnology.SelectedItems.Count <= 0 || txtFirstName.Text == "")
            {
                MessageBox.Show("Please select atleast one technology");
            }
            else
            {

                Candidate cand = new Candidate();
                Boolean isSuccess;
                cand.FirstName = txtFirstName.Text;
                cand.LastName = txtLastName.Text;

                DataTable table = new DataTable();
                table.Columns.Add("TechID");
                table.Columns.Add("TechnologyName");
                
                // get TechnologyIds to insert into CandidateTech table

                for (int i = 0; i < lvTechnology.SelectedItems.Count; i++)
                {
                    ListViewItem item = lvTechnology.SelectedItems[i];
                    for (int j = 0; j < item.SubItems.Count; j++)
                    {
                        if (j == 0) // skipping Technology name, can use if needed.
                        {
                            var it = item.SubItems[j];
                            table.Rows.Add(it.Text);
                        }
                    }
                }
                isSuccess = cand.addCandidate(cand, table);
                if (isSuccess == true)
                {
                    MessageBox.Show("Candidate Added Successfully");
                    lvTechnology.TopItem.Selected = true;
                    txtFirstName.Text = "";
                    txtLastName.Text = "";
                    txtFirstName.Focus();

                }
                else { MessageBox.Show("Record not saved");  }

            }

        }

        private void txtFirstName_Leave(object sender, EventArgs e)
        {
            if (txtFirstName.Text == "")
            {
                MessageBox.Show("First Name can not be blank");
                txtFirstName.Focus();
            }
            
        }

        #endregion

        private void lvTechnology_Leave(object sender, EventArgs e)
        {
            lvTechnology.HideSelection = false;
        }
    }

}
