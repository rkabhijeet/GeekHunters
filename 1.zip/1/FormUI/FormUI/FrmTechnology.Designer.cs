﻿namespace FormUI
{
    partial class FrmTechnology
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTech = new System.Windows.Forms.TextBox();
            this.btnTSubmit = new System.Windows.Forms.Button();
            this.lblTech = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtTech
            // 
            this.txtTech.Location = new System.Drawing.Point(166, 83);
            this.txtTech.Name = "txtTech";
            this.txtTech.Size = new System.Drawing.Size(150, 20);
            this.txtTech.TabIndex = 0;
            this.txtTech.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // btnTSubmit
            // 
            this.btnTSubmit.Location = new System.Drawing.Point(241, 133);
            this.btnTSubmit.Name = "btnTSubmit";
            this.btnTSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnTSubmit.TabIndex = 1;
            this.btnTSubmit.Text = "Submit";
            this.btnTSubmit.UseVisualStyleBackColor = true;
            this.btnTSubmit.Click += new System.EventHandler(this.btnTSubmit_Click);
            // 
            // lblTech
            // 
            this.lblTech.AutoSize = true;
            this.lblTech.Location = new System.Drawing.Point(31, 86);
            this.lblTech.Name = "lblTech";
            this.lblTech.Size = new System.Drawing.Size(91, 13);
            this.lblTech.TabIndex = 2;
            this.lblTech.Text = "Enter Technology";
            // 
            // FrmTechnology
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 462);
            this.Controls.Add(this.lblTech);
            this.Controls.Add(this.btnTSubmit);
            this.Controls.Add(this.txtTech);
            this.Name = "FrmTechnology";
            this.Text = "FrmTechnology";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTech;
        private System.Windows.Forms.Button btnTSubmit;
        private System.Windows.Forms.Label lblTech;
    }
}