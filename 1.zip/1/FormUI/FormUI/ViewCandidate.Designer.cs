﻿namespace FormUI
{
    partial class ViewCandidate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnView = new System.Windows.Forms.Button();
            this.gvCandTech = new System.Windows.Forms.DataGridView();
            this.cmbTech = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.gvCandTech)).BeginInit();
            this.SuspendLayout();
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(265, 39);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(75, 23);
            this.btnView.TabIndex = 1;
            this.btnView.Text = "View";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // gvCandTech
            // 
            this.gvCandTech.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvCandTech.Location = new System.Drawing.Point(40, 85);
            this.gvCandTech.Name = "gvCandTech";
            this.gvCandTech.Size = new System.Drawing.Size(300, 339);
            this.gvCandTech.TabIndex = 2;
            // 
            // cmbTech
            // 
            this.cmbTech.FormattingEnabled = true;
            this.cmbTech.Location = new System.Drawing.Point(40, 39);
            this.cmbTech.Name = "cmbTech";
            this.cmbTech.Size = new System.Drawing.Size(185, 21);
            this.cmbTech.TabIndex = 3;
            // 
            // ViewCandidate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 462);
            this.Controls.Add(this.cmbTech);
            this.Controls.Add(this.gvCandTech);
            this.Controls.Add(this.btnView);
            this.Name = "ViewCandidate";
            this.Text = "ViewCandidate";
            this.Load += new System.EventHandler(this.ViewCandidate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvCandTech)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.DataGridView gvCandTech;
        private System.Windows.Forms.ComboBox cmbTech;
    }
}