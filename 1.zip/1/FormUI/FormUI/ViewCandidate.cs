﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CandidateTechLibrary;


namespace FormUI
{
    public partial class ViewCandidate : Form
    {
        public ViewCandidate()
        {
            InitializeComponent();
        }

        DataTable dtCandTech = new DataTable();

        private void btnView_Click(object sender, EventArgs e)
        {

            DataTable alldt = new DataTable();
            alldt.Columns.Add("FirstName", typeof(string));
            alldt.Columns.Add("LastName", typeof(string));
            
            if (cmbTech.SelectedValue.ToString() == "")
            {
                var groups = dtCandTech.AsEnumerable()
                    .GroupBy(r => r.Field<int>("CandidateID"));
                foreach (var group in groups)
                {
                    alldt.Rows.Add((group.First())["FirstName"], (group.First())["LastName"]);
                }
                
            }
            else
            {
                int selected = (int)cmbTech.SelectedValue;
                var que = from r in dtCandTech.AsEnumerable()
                          where r.Field<int>("TechID") == selected
                          let objArray = new object[]
                          {
                              r.Field<string>("FirstName"), r.Field<string>("LastName")
                          }
                          select objArray;
                foreach (var q in que)
                {
                    alldt.Rows.Add(q);
                }
            }
            gvCandTech.DataSource = alldt;
            gvCandTech.ReadOnly = true;
            if (alldt.Rows.Count == 0)
            {
                MessageBox.Show("No records to show");
            }
            
        }

        private void ViewCandidate_Load(object sender, EventArgs e)
        {
            //Get data for combobox
            DataTable dtTech = new DataTable();
            //IEqualityComparer <DataRow> techList;
            Technology Tech = new Technology();
            dtTech = Tech.selectTechnologyNames();
            
            //attach datasource
            dtTech.Rows.Add(DBNull.Value, "SelectAll");
            cmbTech.DisplayMember = "TechnologyName";
            cmbTech.ValueMember = "TechID";
            cmbTech.DataSource = dtTech;
            cmbTech.DropDownStyle = ComboBoxStyle.DropDownList;

            
            CandidateTech CandTech = new CandidateTech();
            dtCandTech = CandTech.selectAllCandTech();


        }
    }
}
