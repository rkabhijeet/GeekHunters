﻿using System;
using CandidateTechLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestGeekhunter
{
    [TestClass]
    public class TechnologyTests
    {
        [TestMethod]
        public void AddTechnology_successfull()
        {
            var tech = new Technology();
            var result = tech.addTechnology(new Technology { TechnologyName = "TSQL" });
            Assert.IsTrue(result);
        }
    }
}
