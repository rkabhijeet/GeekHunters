﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DataLayerConnect
{
    public class CandidateService
    {
        public Boolean InsertCandidate(string fname, string lname, DataTable table)

        {
            
            DBConnection dBConn = new DBConnection();
            IDBConnection dBConnection = (IDBConnection)dBConn;
            dBConnection.Sql = "INSERT INTO Candidate (  FirstName , LastName)  VALUES ( '" + fname + "' , '" + lname + "'); SELECT SCOPE_IDENTITY();";
            dBConnection.Open();
            int modified = dBConn.executegetID();
            dBConnection.Close();

            if (modified > 0)
            {
                //AddCandTech(modified, table);
                Boolean success;
                dBConnection.Sql = "";
                dBConnection.Open();
                success = dBConn.executeCandTech(modified, table);
                dBConnection.Close();
                return success;
            }
            else { return false; }
        }

        
    }
}
