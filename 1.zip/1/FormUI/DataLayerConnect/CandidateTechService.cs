﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerConnect
{
    public class CandidateTechService
    {
        public DataTable SelectCandidateTechnology()

        {
            DataTable dt = new DataTable();
            DBConnection dBConn = new DBConnection();
            IDBConnection dBConnection = (IDBConnection)dBConn;
            dBConnection.Sql = "SELECT c.FirstName, C.LastName, ct.CandidateID       ,ct.TechID, t.TechnologyName   FROM CandidateTech ct   join Technology t on ct.TechID = t.TechID   join Candidate c on ct.CandidateID = c.CandidateID";
            // dBConnection.Sql = "SELECT FirstName, LastName FROM Candidate";
            dBConnection.Open();
            dt = dBConn.FillData();
            dBConnection.Close();
            return dt;

            
        }
    }
}
