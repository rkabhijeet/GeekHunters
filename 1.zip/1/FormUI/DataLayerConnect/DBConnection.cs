﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace DataLayerConnect
{
    class DBConnection : IDBConnection
    {
        
        //SqlConnection con = new SqlConnection("Integrated Security=SSPI;Initial Catalog=GeekHunter;Data Source=ABHIJIT-PC\\SQLEXPRESS");
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Geekhunter"].ConnectionString.ToString());

        public string Sql
        {
            get;
            set;
        }

        public void Open()
        {
            try
            {
                con.Open();
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Insert and return PK
        public int executegetID()
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = Sql;
                cmd.Connection = con;
                int modified = Convert.ToInt32(cmd.ExecuteScalar());
                return modified;
            }
            catch (Exception e)
            {
                 throw e;
            }
        }

        // insert technology details for candidate
        public Boolean executeCandTech(int CandID, DataTable dt)
        {
            try
            {  
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                    Sql = "INSERT INTO CandidateTech(CandidateID , TechID) VALUES (" + CandID + "," + dt.Rows[i][0] + ")";
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = Sql;
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                }

                return true;
            }
            catch (Exception e)
            {

                throw e;
            }
        }


        public void execute1()
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = Sql;
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {

                throw;
            }
        }


        public DataTable FillData()
        {
            SqlCommand cmd = new SqlCommand(Sql, con);
            cmd.CommandType = CommandType.Text;
            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
            {
                DataTable dt = new DataTable();
                sda.Fill(dt);
                return dt;
            }
        }


        public void Close()
        {
            con.Close();
        }

        
    }
}
