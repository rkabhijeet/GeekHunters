﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerConnect
{
    public class TechnologyService
    {
        public DataTable SelectTechnologies()

        {
            
            DataTable dt = new DataTable();
            DBConnection dBConn = new DBConnection();
            IDBConnection dBConnection = (IDBConnection)dBConn;
            dBConnection.Sql = "Select TechID, TechnologyName From Technology";
            dBConnection.Open();
            dt = dBConn.FillData();
            dBConnection.Close();
            return dt;
        }

        public Boolean InsertTechnology(string techName)

        {
            
            DBConnection dBConn = new DBConnection();
            IDBConnection dBConnection = (IDBConnection)dBConn;
            dBConnection.Sql = "INSERT INTO Technology (  TechnologyName )  VALUES ( '" + techName + "'); SELECT SCOPE_IDENTITY();";
            dBConnection.Open();
            int modified = dBConn.executegetID();
            dBConnection.Close();

            if (modified > 0)
            {
                return true;
            }
            else { return false; }
        }
    }
}
