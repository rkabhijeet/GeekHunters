﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayerConnect
{
    public interface IDBConnection
    {
        ///// <summary>
        ///// Gets or sets the connection string as/in text
        ///// </summary>
        //string Text { get; set; }



        /// <summary>
        /// Gets or sets the Transact-SQL statement, table name or stored procedure to execute at the data source.
        /// </summary>
        string Sql { get; set; }

        ///// <summary>
        ///// Gets or sets a value indicating how the CommandText property is to be interpreted.
        ///// Allows dynamic adjustment of the type of command before any operation.
        ///// </summary>
        //CommandType CommandType { get; set; }

        #region OpenClose connection

        /// <summary>
        /// Opens a connection to the database.
        /// </summary>
        /// <returns>Returns true if the connection is opened successfully.</returns>
        void Open();

        /// <summary>
        /// Closes connection to database.
        /// </summary>
        void Close();

        #endregion





    }
}
